# Java-Card-Applications

This application simulates the GeldAutomat and Smart Card Reader. For the documentation please visit my github page,
[http://mallikarjuntirlapur.github.io/JavaCard/]

##The Toolchains,
* NetBeans IDE 8.0.2
* Java Card SDK 3.0.2
* JDK 1.7.0_79

## The instructions,
* Download the projects into your local machine.
* Run the java card applet project first.
* Set the AID values to establish the connection and for selecting the applet
* run the GelAutomat project.

##License
MIT

Please let me know, if you face any problems.
